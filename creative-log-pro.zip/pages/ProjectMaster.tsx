
import React, { useState, useMemo } from 'react';
import { Project, Designer } from '../types';

interface Props {
  projects: Project[];
  designers: Designer[];
  onUpdate: (projects: Project[]) => void;
}

const ProjectMaster: React.FC<Props> = ({ projects, designers, onUpdate }) => {
  const [view, setView] = useState<'list' | 'calendar'>('list');
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [currentDate, setCurrentDate] = useState(new Date());
  
  const [formData, setFormData] = useState<Partial<Project>>({
    project_name: '',
    start_date: '',
    end_date: '',
    location: '',
    pic_designer_id: designers[0]?.id || '',
    project_type: 'Campaign'
  });

  const getDesignerName = (id: string) => designers.find(d => d.id === id)?.name || 'N/A';

  const resetForm = () => {
    setFormData({
      project_name: '',
      start_date: '',
      end_date: '',
      location: '',
      pic_designer_id: designers[0]?.id || '',
      project_type: 'Campaign'
    });
    setEditingId(null);
    setIsAdding(false);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.project_name) return;

    if (editingId) {
      onUpdate(projects.map(p => p.id === editingId ? { ...p, ...formData as Project } : p));
    } else {
      const newProj: Project = {
        ...formData as Project,
        id: `p-${Date.now()}`,
        support_designer_ids: []
      };
      onUpdate([...projects, newProj]);
    }
    resetForm();
  };

  const handleEdit = (p: Project) => {
    setFormData(p);
    setEditingId(p.id);
    setIsAdding(true);
    setView('list');
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to remove this project?')) {
      onUpdate(projects.filter(p => p.id !== id));
    }
  };

  const getColorTheme = (id: string) => {
    const themes = [
      { bg: 'bg-blue-50', border: 'border-blue-600', text: 'text-blue-900', accent: 'text-blue-700' },
      { bg: 'bg-amber-50', border: 'border-amber-600', text: 'text-amber-900', accent: 'text-amber-700' },
      { bg: 'bg-emerald-50', border: 'border-emerald-600', text: 'text-emerald-900', accent: 'text-emerald-700' },
      { bg: 'bg-rose-50', border: 'border-rose-600', text: 'text-rose-900', accent: 'text-rose-700' },
      { bg: 'bg-indigo-50', border: 'border-indigo-600', text: 'text-indigo-900', accent: 'text-indigo-700' },
      { bg: 'bg-violet-50', border: 'border-violet-600', text: 'text-violet-900', accent: 'text-violet-700' },
      { bg: 'bg-cyan-50', border: 'border-cyan-600', text: 'text-cyan-900', accent: 'text-cyan-700' },
      { bg: 'bg-orange-50', border: 'border-orange-600', text: 'text-orange-900', accent: 'text-orange-700' },
    ];
    let hash = 0;
    for (let i = 0; i < id.length; i++) hash = id.charCodeAt(i) + ((hash << 5) - hash);
    return themes[Math.abs(hash) % themes.length];
  };

  const daysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = (year: number, month: number) => new Date(year, month, 1).getDay();
  const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const sortedProjects = useMemo(() => [...projects].sort((a, b) => a.id.localeCompare(b.id)), [projects]);

  const navigateMonth = (direction: number) => {
    setCurrentDate(prev => new Date(prev.getFullYear(), prev.getMonth() + direction, 1));
  };

  const renderCalendar = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const totalDays = daysInMonth(year, month);
    const startDay = firstDayOfMonth(year, month);
    const days = [];
    for (let i = 0; i < startDay; i++) days.push(<div key={`empty-${i}`} className="min-h-[160px] bg-slate-100/50 border-r border-b border-slate-200"></div>);
    for (let d = 1; d <= totalDays; d++) {
      const dayOfWeek = (startDay + d - 1) % 7;
      const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      const dayProjects = sortedProjects.filter(p => dateStr >= p.start_date && dateStr <= p.end_date);
      days.push(
        <div key={d} className="min-h-[160px] h-full bg-white border-r border-b border-slate-200 p-0 flex flex-col relative">
          <span className="text-[10px] font-black text-slate-700 block p-2">{String(d).padStart(2, '0')}</span>
          <div className="flex flex-col space-y-1 pb-2">
            {dayProjects.map(p => {
              const theme = getColorTheme(p.id);
              const isStart = dateStr === p.start_date;
              const designerName = getDesignerName(p.pic_designer_id);
              return (
                <div key={p.id} className={`min-h-[56px] py-1.5 flex flex-col justify-center px-2 overflow-hidden ${isStart ? `rounded-l-md ml-1 border-l-4 ${theme.border}` : ''} ${theme.bg} ${theme.text}`}>
                  <div className="flex flex-col min-w-0 leading-tight">
                    <span className="text-[10px] font-black truncate">{p.project_name}</span>
                    <span className={`text-[8px] font-black opacity-80 mt-0.5 truncate uppercase tracking-tighter`}>PIC: {designerName}</span>
                    <span className={`text-[8px] font-bold ${theme.accent} truncate mt-0.5`}>{p.location || 'Remote'}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      );
    }
    return days;
  };

  const labelClass = "text-[11px] font-black text-slate-900 uppercase mb-1.5 block";
  const inputClass = "w-full rounded-lg border-slate-300 text-slate-900 text-sm p-3 border bg-white focus:ring-2 focus:ring-indigo-600 outline-none placeholder-slate-400 font-semibold shadow-sm appearance-none";

  return (
    <div className="space-y-6 flex flex-col h-full">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 flex-shrink-0">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">Project Master</h1>
          <p className="text-slate-600 text-sm mt-1 font-bold">Visualizing timelines with unique project identifiers.</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center bg-slate-200 p-1 rounded-xl">
            <button onClick={() => setView('list')} className={`px-4 py-1.5 rounded-lg text-xs font-black transition-all ${view === 'list' ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}>List View</button>
            <button onClick={() => setView('calendar')} className={`px-4 py-1.5 rounded-lg text-xs font-black transition-all ${view === 'calendar' ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}>Calendar View</button>
          </div>
          {!isAdding && view === 'list' && (
            <button onClick={() => setIsAdding(true)} className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-black flex items-center gap-2 shadow-lg hover:bg-indigo-700 transition-all">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 4v16m8-8H4"/></svg>
              Add Project
            </button>
          )}
        </div>
      </header>

      {isAdding && (
        <form onSubmit={handleSave} className="bg-white p-8 rounded-2xl border border-slate-200 shadow-xl animate-in zoom-in duration-200 flex-shrink-0">
          <h2 className="font-black text-slate-900 mb-8 flex items-center gap-2">
            <span className="w-2 h-2 bg-indigo-600 rounded-full"></span>
            {editingId ? 'Edit Project Details' : 'Register New Project'}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div className="md:col-span-2">
              <label className={labelClass}>Project Name</label>
              <input type="text" required value={formData.project_name} onChange={e => setFormData({...formData, project_name: e.target.value})} className={inputClass} placeholder="e.g. Annual Report 2024" />
            </div>
            <div className="relative">
              <label className={labelClass}>Project Type</label>
              <select value={formData.project_type} onChange={e => setFormData({...formData, project_type: e.target.value})} className={inputClass}>
                <option value="Campaign">Campaign</option>
                <option value="Identity">Identity</option>
                <option value="Event">Event</option>
                <option value="Internal">Internal</option>
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 top-6 flex items-center px-3 text-slate-500">
                <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 9l-7 7-7-7" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
              </div>
            </div>
            <div>
              <label className={labelClass}>Start Date</label>
              <input type="date" required value={formData.start_date} onChange={e => setFormData({...formData, start_date: e.target.value})} className={inputClass} />
            </div>
            <div>
              <label className={labelClass}>End Date</label>
              <input type="date" required value={formData.end_date} onChange={e => setFormData({...formData, end_date: e.target.value})} className={inputClass} />
            </div>
            <div>
              <label className={labelClass}>Location</label>
              <input type="text" placeholder="e.g. Remote, HQ" value={formData.location} onChange={e => setFormData({...formData, location: e.target.value})} className={inputClass} />
            </div>
            <div className="relative">
              <label className={labelClass}>Lead Designer (PIC)</label>
              <select value={formData.pic_designer_id} onChange={e => setFormData({...formData, pic_designer_id: e.target.value})} className={inputClass}>
                {designers.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 top-6 flex items-center px-3 text-slate-500">
                <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 9l-7 7-7-7" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
              </div>
            </div>
          </div>
          <div className="flex justify-end gap-4 pt-6 border-t border-slate-100">
            <button type="button" onClick={resetForm} className="px-6 py-2.5 text-sm font-black text-slate-700 hover:text-slate-900 transition-colors">Cancel</button>
            <button type="submit" className="px-8 py-2.5 bg-indigo-600 text-white rounded-lg text-sm font-black shadow-lg hover:bg-indigo-700 transition-all">
              {editingId ? 'Update Project' : 'Register Project'}
            </button>
          </div>
        </form>
      )}

      <div className="flex-1 min-h-0">
        {view === 'list' ? (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-full animate-in fade-in duration-300">
            <div className="overflow-y-auto max-h-full">
              <table className="w-full text-left text-sm border-collapse">
                <thead className="sticky top-0 z-10 bg-slate-100">
                  <tr className="text-slate-900 font-black uppercase text-[10px] tracking-wider border-b border-slate-200">
                    <th className="px-6 py-4">Project Name</th>
                    <th className="px-6 py-4">Timeline</th>
                    <th className="px-6 py-4">Location</th>
                    <th className="px-6 py-4">Lead Designer</th>
                    <th className="px-6 py-4">Type</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-900 font-bold">
                  {projects.length === 0 ? (
                    <tr><td colSpan={6} className="px-6 py-12 text-center text-slate-500 italic">No projects registered.</td></tr>
                  ) : projects.map(p => (
                    <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 font-black">{p.project_name}</td>
                      <td className="px-6 py-4 text-[11px]">
                        <span className="bg-white border-slate-300 border px-2 py-0.5 rounded">{p.start_date}</span>
                        <span className="mx-2 text-slate-400">→</span>
                        <span className="bg-white border-slate-300 border px-2 py-0.5 rounded">{p.end_date}</span>
                      </td>
                      <td className="px-6 py-4 uppercase tracking-tight text-xs">{p.location || '—'}</td>
                      <td className="px-6 py-4">{getDesignerName(p.pic_designer_id)}</td>
                      <td className="px-6 py-4">
                        <span className="bg-indigo-50 text-indigo-800 px-2 py-1 rounded text-[10px] font-black uppercase tracking-tight">{p.project_type}</span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-4">
                          <button onClick={() => handleEdit(p)} className="text-indigo-700 hover:text-indigo-900 text-[10px] font-black uppercase tracking-widest">Edit</button>
                          <button onClick={() => handleDelete(p.id)} className="text-red-500 hover:text-red-700 text-[10px] font-black uppercase tracking-widest">Delete</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden h-full flex flex-col animate-in fade-in duration-300">
            <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between flex-shrink-0">
              <h3 className="font-black text-slate-900 text-sm uppercase tracking-widest">{monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}</h3>
              <div className="flex gap-2">
                <button onClick={() => navigateMonth(-1)} className="p-1.5 hover:bg-slate-300 rounded-lg transition-colors"><svg className="w-5 h-5 text-slate-800" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15 19l-7-7 7-7"/></svg></button>
                <button onClick={() => setCurrentDate(new Date())} className="px-3 py-1 text-[10px] font-black uppercase tracking-widest bg-white border border-slate-300 rounded-lg text-slate-900">Today</button>
                <button onClick={() => navigateMonth(1)} className="p-1.5 hover:bg-slate-300 rounded-lg transition-colors"><svg className="w-5 h-5 text-slate-800" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 5l7 7-7 7"/></svg></button>
              </div>
            </div>
            <div className="overflow-y-auto flex-1">
              <div className="grid grid-cols-7 border-b border-slate-200 bg-slate-100">
                {['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].map(d => (
                  <div key={d} className="py-3 text-center text-[10px] font-black text-slate-900 uppercase tracking-widest border-r border-slate-200 last:border-0">{d}</div>
                ))}
              </div>
              <div className="grid grid-cols-7 border-l border-slate-200">{renderCalendar()}</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProjectMaster;
